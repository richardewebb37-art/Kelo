<?php
/**
 * Plugin Name: Pro Icons for Gutenberg WordPress Editor 
 * Description: The Pro Icon block allows you to place a custom icon into any block / post / page in an easy and interactive way!
 * Version: 1.0.0
 * Author: AA-Team
 * Author URI: http://www.aa-team.com
 * Text Domain: pro-icons
 * Domain Path: /languages
 *
 * @package pro-icons
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (class_exists('AAT_ICOPRO') != true) {
	class AAT_ICOPRO
	{
		protected static $instance = null;

		public static function getInstance()
	    {
	        if (!isset(static::$instance)) {
	            static::$instance = new static;
	        }
	        return static::$instance;
	    }

		protected function __construct()
		{
			add_action( 'init', array( $this, 'init' ), 9 );
		}
		
		public function init()
		{
			if( is_admin() ){
				$this->editor_assets();
			}else{
				$this->frontend_assets();
			}
		}

		public function frontend_assets()
		{
			wp_enqueue_style(
				'iconpro/design',
				plugins_url( 'build/frontend/frontend.view.css', __FILE__ )
			);

			wp_enqueue_script(
				'iconpro/design',
				plugins_url( 'build/frontend/frontend.build.js', __FILE__ )
		  	);

		  	wp_localize_script( 'iconpro/design', 'ICONPRO', array(
				'assets_url' => plugins_url( '/', __FILE__ ),
				'fonts' => array(),
			) );
		}

		public function editor_assets()
		{
		  	wp_enqueue_script(
				'iconpro/design',
				plugins_url( 'build/icons/icons.build.js', __FILE__ ),
				array( 'wp-blocks', 'wp-element', 'wp-editor' )
		  	);

		  	wp_localize_script( 'iconpro/design', 'ICONPRO', array(
				'assets_url' => plugins_url( '/', __FILE__ ),
				'fonts' => array(),
			) );

		  	wp_enqueue_style(
				'iconpro/design',
				plugins_url( 'build/icons/icons.editor.css', __FILE__ ),
				array( 'wp-edit-blocks' )
			);
			
			wp_enqueue_style(
				'iconpro/design',
				plugins_url( 'build/backend/backend.editor.css', __FILE__ ),
				array( 'wp-edit-blocks' )
			);
		}
	}
}


$AAT_ICOPRO = AAT_ICOPRO::getInstance();
function AAT_ICOPRO() {
	global $AAT_ICOPRO;
	return $AAT_ICOPRO;
}